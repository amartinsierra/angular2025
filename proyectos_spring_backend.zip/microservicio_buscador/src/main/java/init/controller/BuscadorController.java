package init.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import init.model.Item;
import init.service.BuscadorService;

@CrossOrigin("*")
@RestController
public class BuscadorController {
	@Autowired
	BuscadorService buscadorService;
	@GetMapping(value="buscar",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Item>> buscar(@RequestParam("tematica") String tematica){
		//return new ResponseEntity<>(buscadorService.buscar(tematica),HttpStatus.OK);
		return ResponseEntity.ok(buscadorService.buscar(tematica));
	}
	
	@PostMapping(value="alta",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> alta(@RequestBody Item item) {
		if(buscadorService.alta(item)) {
			return new ResponseEntity<>(HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.CONFLICT);
	}
	
	//eliminar items por temática: recibe como parámetro la tematica y elimina todos los items
	//de dicha temática. Devuelve la lista de items que quedan en la colección
	@DeleteMapping(value="eliminar",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Item>> eliminar(@RequestParam("tematica") String tematica){
		List<Item> restantes=buscadorService.eliminar(tematica);
		HttpHeaders headers=new HttpHeaders();
		headers.add("total",String.valueOf(restantes.size()));
		return new ResponseEntity<>(restantes,headers,HttpStatus.OK);
	}
}
