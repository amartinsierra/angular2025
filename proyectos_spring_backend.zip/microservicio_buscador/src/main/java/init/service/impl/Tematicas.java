package init.service.impl;

public enum Tematicas {
	LIBROS,VIAJES,MUSICA,DEPORTES;
}
