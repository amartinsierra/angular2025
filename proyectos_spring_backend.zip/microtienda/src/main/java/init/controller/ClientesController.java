package init.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import init.model.Cliente;
import init.service.ClientesService;
@CrossOrigin("*")
@RestController
@RequestMapping("/clientes")
public class ClientesController {

    private final ClientesService clientesService;

    public ClientesController(ClientesService clientesService) {
        this.clientesService = clientesService;
    }

    // Endpoint para login de cliente
    @GetMapping("/login")
    public Cliente login(@RequestParam String usuario, @RequestParam String password) {
        return clientesService.login(usuario, password);
    }

    // Endpoint para verificar si un usuario existe
    @GetMapping(value="/existe/{usuario}",produces=MediaType.APPLICATION_JSON_VALUE)
    public boolean existeUsuario(@PathVariable String usuario) {
    	System.out.println(usuario);
        return clientesService.existeUsuario(usuario);
    }

    // Endpoint para dar de alta un nuevo cliente
    @PostMapping(value="/alta",produces=MediaType.APPLICATION_JSON_VALUE)
    public boolean altaCliente(@RequestBody Cliente cliente) {
        return clientesService.alta(cliente);
    }
}
