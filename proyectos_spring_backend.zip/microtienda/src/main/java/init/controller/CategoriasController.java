package init.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import init.model.Categoria;
import init.service.CategoriasService;
@CrossOrigin("*")
@RestController
@RequestMapping("/categorias")
public class CategoriasController {

    private final CategoriasService categoriasService;

    public CategoriasController(CategoriasService categoriasService) {
        this.categoriasService = categoriasService;
    }

    // Endpoint para obtener todas las categorías
    @GetMapping
    public List<Categoria> obtenerCategorias() {
        return categoriasService.categorias();
    }
}
