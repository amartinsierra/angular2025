package init.controller;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import init.model.Producto;
import init.service.ProductosService;
@CrossOrigin("*")
@RestController
@RequestMapping("/productos")
public class ProductosController {

    private final ProductosService productosService;

    public ProductosController(ProductosService productosService) {
        this.productosService = productosService;
    }

    // Obtener productos por categoría
    @GetMapping("/categoria/{idCategoria}")
    public List<Producto> obtenerProductosPorCategoria(@PathVariable int idCategoria) {
        return productosService.productosCategoria(idCategoria);
    }

    // Obtener producto por código
    @GetMapping("/{codigo}")
    public Producto obtenerProductoPorCodigo(@PathVariable int codigo) {
        return productosService.productoCodigo(codigo);
    }

    // Guardar un nuevo producto
    @PostMapping
    public boolean guardarProducto(@RequestBody Producto producto) {
        return productosService.guardarProducto(producto);
    }

    // Eliminar producto por código
    @DeleteMapping("/{codigo}")
    public void eliminarProducto(@PathVariable int codigo) {
        productosService.eliminarProducto(codigo);
    }
}
