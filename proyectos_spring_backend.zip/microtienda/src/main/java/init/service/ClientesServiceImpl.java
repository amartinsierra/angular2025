package init.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import init.model.Cliente;
@Service
public class ClientesServiceImpl implements ClientesService {
	List<Cliente> clientes=new ArrayList<>(List.of(new Cliente("cliente1","email1@gmail.com","user1","pass1"),
			new Cliente("cliente2","email2@gmail.com","user2","pass2"),
			new Cliente("cliente3","email3@gmail.com","user3","pass3"),
			new Cliente("cliente4","email4@gmail.com","user4","pass4")
			));

	@Override
	public Cliente login(String usuario, String password) {
		return clientes.stream()
				.filter(c->c.getUsuario().equals(usuario)&&c.getPassword().equals(password))
				.findFirst()
				.orElse(null);
	}

	@Override
	public boolean existeUsuario(String usuario) {
		return clientes.stream()
				.anyMatch(c->c.getUsuario().equals(usuario));
	}

	@Override
	public boolean alta(Cliente cliente) {
		if(!existeUsuario(cliente.getUsuario())) {
			clientes.add(cliente);
			return true;
		}
		return false;
	}

}
