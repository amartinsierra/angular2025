package init.service;

import java.util.List;

import init.model.Producto;

public interface ProductosService {
	List<Producto> productosCategoria(int idCategoria);
	Producto productoCodigo(int codigo);
	boolean guardarProducto(Producto producto);
	void eliminarProducto(int codigo);
}
