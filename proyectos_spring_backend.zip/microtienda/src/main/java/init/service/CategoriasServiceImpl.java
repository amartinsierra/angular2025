package init.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import init.model.Categoria;
@Service
public class CategoriasServiceImpl implements CategoriasService {
	List<Categoria> categorias=new ArrayList<>(List.of(
			new Categoria(1, "Electrónica", "TechWorld"),
	        new Categoria(2, "Ropa", "FashionStyle"),
	        new Categoria(3, "Alimentos", "FreshMarket"),
	        new Categoria(4, "Juguetes", "ToyPlanet"),
	        new Categoria(5, "Muebles", "HomeDeco"),
	        new Categoria(6, "Deportes", "SportGear")
			));
	@Override
	public List<Categoria> categorias() {
		return categorias;
	}

}
