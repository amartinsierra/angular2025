package init.service;

import java.util.List;

import init.model.Categoria;

public interface CategoriasService {
	List<Categoria> categorias();
}
