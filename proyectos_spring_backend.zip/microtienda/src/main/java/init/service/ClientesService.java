package init.service;

import init.model.Cliente;

public interface ClientesService {
	Cliente login(String usuario, String password);
	boolean existeUsuario(String usuario);
	boolean alta(Cliente cliente);
}
