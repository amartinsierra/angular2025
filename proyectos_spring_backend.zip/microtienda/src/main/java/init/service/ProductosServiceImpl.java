package init.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import init.model.Producto;
@Service
public class ProductosServiceImpl implements ProductosService {
    private List<Producto> productos;

    public ProductosServiceImpl() {
        this.productos = new ArrayList<>();

        // Inicializar la lista con los 10 productos de antes
        productos.add(new Producto(101, "Smartphone", 599.99, 1));
        productos.add(new Producto(102, "Laptop", 1099.50, 1));
        productos.add(new Producto(103, "Camiseta", 19.99, 2));
        productos.add(new Producto(104, "Pantalón vaquero", 39.99, 2));
        productos.add(new Producto(105, "Chocolate negro", 4.50, 3));
        productos.add(new Producto(106, "Pelota de fútbol", 25.75, 6));
        productos.add(new Producto(107, "Muñeca", 18.99, 4));
        productos.add(new Producto(108, "Sofá de 3 plazas", 499.99, 5));
        productos.add(new Producto(109, "Auriculares inalámbricos", 89.99, 1));
        productos.add(new Producto(110, "Mesa de comedor", 299.99, 5));
    }

    @Override
    public List<Producto> productosCategoria(int idCategoria) {
        List<Producto> resultado = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getIdCategoria() == idCategoria) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    @Override
    public Producto productoCodigo(int codigo) {
        Optional<Producto> producto = productos.stream()
                .filter(p -> p.getCodigo() == codigo)
                .findFirst();
        return producto.orElse(null);
    }

    @Override
    public boolean guardarProducto(Producto producto) {
        if (productoCodigo(producto.getCodigo()) == null) {
            productos.add(producto);
            return true;
        }
        return false; // No se guarda si ya existe un producto con el mismo código
    }

    @Override
    public void eliminarProducto(int codigo) {
        productos.removeIf(p -> p.getCodigo() == codigo);
    }
}